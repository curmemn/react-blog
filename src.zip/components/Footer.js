import React from 'react'

const Footer = () => {
  return (
    <div className='footer'>Footer</div>
  )
}

export default Footer