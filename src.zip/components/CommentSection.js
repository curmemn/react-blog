import React from 'react'

const CommentSection = () => {
  return (
    <div>CommentSection</div>
  )
}

export default CommentSection